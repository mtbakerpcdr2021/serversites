<h2 style="color: #96588a; display: block; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; font-size: 18px; font-weight: bold; line-height: 130%; margin: 0 0 18px; text-align: left;">
    <?php echo $method_title ?>
</h2>

<p style="margin: 0 0 16px;">Payment method not available, please contact the store owner for manual payment</p>
